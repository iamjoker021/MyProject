﻿using MyProject.Models;
using MyProject.Repository.IRepository;
using Newtonsoft.Json;

namespace MyProject.Repository
{
    public class ProcessPensionRepository : Repository<ProcessPension>, IProcessPensionRepository
    {
        private readonly IHttpClientFactory _clientFactory;
        public ProcessPensionRepository(IHttpClientFactory clientFactory): base(clientFactory)
        {
            _clientFactory = clientFactory;
        }
    }
}
