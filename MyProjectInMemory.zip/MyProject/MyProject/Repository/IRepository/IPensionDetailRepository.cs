﻿using MyProject.Models;

namespace MyProject.Repository
{
    public interface IPensionDetailRepository
    {
        public ICollection<PensionerDetail> GetPensionDetails();
        public PensionerDetail GetPensionerDetailByAdhaar(int adaarNumber);
    }
}
