﻿namespace MyProject
{
    public static class StaticDetails
    {
        public static string PensionDetailURL = "";
        public static string pensionDetialPath = "api/PensionerDetailByAdhaar/";
    }
}
