﻿using IdentityServer4;
using IdentityServer4.Models;
using IdentityServer4.Test;

namespace Authentication.Config
{
    public class Config
    {
        public static IEnumerable<Client> Clients => new Client[] { 
            new Client
            {
                ClientId = "pensionClient",
                AllowedGrantTypes = GrantTypes.ClientCredentials,
                ClientSecrets =
                {
                    new Secret ("secret".Sha256())
                },
                AllowedScopes = { "pensionDetails" }
            },
            new Client
            {
                ClientId = "postmanClient",
                ClientName = "Postman Client",
                AccessTokenType = AccessTokenType.Jwt,
                AccessTokenLifetime = 300,
                AllowedGrantTypes = GrantTypes.Code,
                ClientSecrets =
                {
                    new Secret ("secret".Sha256())
                },
                // RedirectUris = new List<string>(){ "https://www.getpostman.com/oauth2/callback" },
                AllowedScopes = { 
                    IdentityServerConstants.StandardScopes.OpenId,
                    IdentityServerConstants.StandardScopes.Profile,
                    "pensionDetails" },
                // PostLogoutRedirectUris = new List<string>{ "url" }
            }
        };

        public static IEnumerable<ApiScope> ApiScopes => new ApiScope[] { 
            new ApiScope("pensionDetails", "PensionDetails")
        };

        public static IEnumerable<ApiResource> ApiResources => new ApiResource[]
        {
            new ApiResource("pensionDetails", "PensionDetails")
        };

        public static IEnumerable<IdentityResource> IdentityResources => new IdentityResource[] { 
            new IdentityResources.OpenId(),
            new IdentityResources.Profile(),
        };

        public static List<TestUser> TestUsers => new List<TestUser> { 
            new TestUser
            {
                SubjectId = "123avd",
                Username = "admin",
                Password = "admin"
            }
        };
    }
}
