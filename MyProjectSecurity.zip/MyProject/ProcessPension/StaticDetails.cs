﻿namespace MyProject
{
    public static class StaticDetails
    {
        public const string PensionDetailURL = "https://localhost:8001/";
        public const string PensionDetialPath = "api/PensionDetail/";
    }
}
