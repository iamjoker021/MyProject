﻿using System.Text;
using MyProject.Data;
using MyProject.Models;

namespace MyProject.Repository
{
    public class PensionDetailRepository: IPensionDetailRepository
    {
        private readonly ApplicationDbContext _db;

        public PensionDetailRepository(ApplicationDbContext db)
        {
            _db = db;
            var data = GetPensionDetails();
            if (data == null || !data.Any() )
            {
                UpdateSeedPensionerDetails();
            }
        }

        public ICollection<PensionerDetail> GetPensionDetails()
        {
            var data = _db.PensionerDetails.ToList<PensionerDetail>();
            return data;
        }

        public PensionerDetail GetPensionerDetailByAdhaar(int adhaarNumber)
        {
            return _db.PensionerDetails.FirstOrDefault(pensionerDetail => pensionerDetail.AdhaarNumber == adhaarNumber);
        }

        public void UpdateSeedPensionerDetails()
        {
            var path = "Repository/PensionDetailsFlatFile.csv";
            var lines = File.ReadLines(path, Encoding.UTF8);

            foreach (var line in lines)
            {
                var pensionerDetail = new PensionerDetail();

                var fields = line.Replace(", ", ",").Split(",");

                pensionerDetail.AdhaarNumber = int.Parse(fields[0]);
                pensionerDetail.Name = fields[1];
                pensionerDetail.DateOfBirth = DateTime.Parse(fields[2]);
                pensionerDetail.PAN = fields[3];
                pensionerDetail.SalaryEarned = int.Parse(fields[4]);
                pensionerDetail.Allowances = int.Parse(fields[5]);
                pensionerDetail.PensionType = fields[6];
                pensionerDetail.BankName = fields[7];
                pensionerDetail.AccountNumber = int.Parse(fields[8]);
                pensionerDetail.BankType = fields[9];

                _db.PensionerDetails.Add(pensionerDetail);

                _db.SaveChanges();

            }
        }
    }
}
