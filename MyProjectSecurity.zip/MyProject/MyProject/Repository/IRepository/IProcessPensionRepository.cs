﻿using MyProject.Models;

namespace MyProject.Repository.IRepository
{
    public interface IProcessPensionRepository: IRepository<ProcessPension>
    {
    }
}
