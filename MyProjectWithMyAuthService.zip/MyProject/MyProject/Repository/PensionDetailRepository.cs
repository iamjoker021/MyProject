﻿using MyProject.Data;
using MyProject.Models;

namespace MyProject.Repository
{
    public class PensionDetailRepository: IPensionDetailRepository
    {
        private readonly ApplicationDbContext _db;

        public PensionDetailRepository(ApplicationDbContext db)
        {
            _db = db;
        }

        public ICollection<PensionerDetail> GetPensionDetails()
        {
            return _db.PensionerDetails.OrderBy(a => a.Name).ToList();
        }

        public PensionerDetail GetPensionerDetailByAdhaar(int adhaarNumber)
        {
            return _db.PensionerDetails.FirstOrDefault(pensionerDetail => pensionerDetail.AdhaarNumber == adhaarNumber);
        }
    }
}
