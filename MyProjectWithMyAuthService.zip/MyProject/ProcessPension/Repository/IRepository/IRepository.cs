﻿namespace MyProject.Repository.IRepository
{
    public interface IRepository<T> where T: class
    {
        Task<T> GetAsync(string url, int Id, string? bearerToken);
    }
}
