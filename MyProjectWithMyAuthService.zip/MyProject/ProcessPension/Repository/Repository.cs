﻿using Microsoft.AspNetCore.Authorization;
using System.Net.Http.Headers;
using Microsoft.Net.Http.Headers;
using MyProject.Repository.IRepository;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;
using MyProject.Models;

namespace MyProject.Repository
{
    public class Repository<T>: IRepository<T> where T: class
    {
        private readonly IHttpClientFactory _clientFactory;

        public Repository(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }
        public async Task<T> GetAsync(string url, int Id, string? bearerToken)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, url + Id);

            var client = _clientFactory.CreateClient();

            // var bearerToken = Request.Headers[HeaderNames.Authorization].ToString();

            if (bearerToken != null) 
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer",bearerToken.Split(' ')[1]);
            }

            HttpResponseMessage response = await client.SendAsync(request);

            if(response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var jsonString = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<T>(jsonString);
            }
            return null;
        }
    }
}
