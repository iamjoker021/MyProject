﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using MyAuthService.Data;
using MyAuthService.Models;

namespace MyAuthService.Repository
{
    public class AuthRepository: IAuthRepository
    {
        private readonly ApplicationDbContext _db;
        private readonly IConfiguration _configuration;

        public AuthRepository(ApplicationDbContext db, IConfiguration configuration)
        {
            _configuration = configuration;
            _db = db;
            var data = GetUserDetails();
            if (data == null || !data.Any() )
            {
                UpdateSeedUserDetails();
            }
        }

        public ICollection<UserDetail> GetUserDetails()
        {
            var data = _db.UserDetails.ToList<UserDetail>();
            return data;
        }

        public UserDetail GetUserByName(string username)
        {
            return _db.UserDetails.FirstOrDefault(userDetail => userDetail.UserName == username);
        }

        public void UpdateSeedUserDetails()
        {
            var path = "Repository/UserDetailsFlatFile.csv";
            var lines = File.ReadLines(path, Encoding.UTF8);

            foreach (var line in lines)
            {
                var userDetail = new UserDetail();

                var fields = line.Replace(", ", ",").Split(",");

                userDetail.UserName = fields[0];
                userDetail.Password = fields[1];

                _db.UserDetails.Add(userDetail);

                _db.SaveChanges();

            }
        }

        public void CreateUser(string username, string password)
        {
            UserDetail user = new UserDetail { UserName = username, Password = password };
            _db.UserDetails.AddAsync(user);
        }
        public bool Authenticate(string username, string password)
        {
            UserDetail user = GetUserByName(username);
            if (user != null && user.Password == password)
            {
                return true;
            }
            return false;
        }

        public string GenerateToken(string username)
        {
            // var secret = _configuration["AuthSecret"];
            // byte[] key = Convert.FromBase64String("secret");
            var handler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration["AuthSecret"]);
            // SymmetricSecurityKey securityKey = new SymmetricSecurityKey(key);
            var descriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[] { new Claim(ClaimTypes.Name, username)}),
                Expires = DateTime.Now.AddMinutes(30),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
            };

            var token = handler.CreateToken(descriptor);
            return handler.WriteToken(token);
        }

        public Object isTokenValid(string token)
        {
            string secret = _configuration["AuthSecret"];
            var key = Encoding.ASCII.GetBytes(secret);
            var handler = new JwtSecurityTokenHandler();
            var validations = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = false,
                ValidateAudience = false
            };
            try
            {
                var claim = handler.ValidateToken(token, validations, out var tokenSecure);
                var result = new { isTokenValid = true, user = claim.Identity.Name };
                return result;
            }
            catch (Exception e)
            {
                var result = new { isTokenValid = false, error = e.Message };
                return result;
            }
        }

    }
}
