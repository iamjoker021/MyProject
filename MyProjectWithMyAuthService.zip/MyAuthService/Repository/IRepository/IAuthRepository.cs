﻿using MyAuthService.Models;

namespace MyAuthService.Repository
{
    public interface IAuthRepository
    {
        public void CreateUser(string username, string password);
        public bool Authenticate(string username, string password);
        public string GenerateToken(string username);
        public Object isTokenValid(string token);
    }
}
