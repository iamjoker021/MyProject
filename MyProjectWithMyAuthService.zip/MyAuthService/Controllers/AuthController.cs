﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MyAuthService.Models;
using MyAuthService.Repository;

namespace MyAuthService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthRepository _userDetailRepo;
        public AuthController(IAuthRepository userDetailRepo)
        {
            _userDetailRepo = userDetailRepo;
        }

        [HttpPost("user/register")]
        public IActionResult Register([FromBody]UserDetail user)
        {
            try
            {
                _userDetailRepo.CreateUser(user.UserName, user.Password);
                return Ok();
            }
            catch (ApplicationException ex) {
                return BadRequest(new { message = ex.Message });
            }

        }

        [HttpPost("authenticate")]
        public IActionResult Authenticate([FromBody] UserDetail user)
        {
            try
            {
                bool isAuthenticated = _userDetailRepo.Authenticate(user.UserName, user.Password);
                if (!isAuthenticated)
                {
                    return BadRequest(new { message = "Username or Password is invalid" });
                }

                string token = _userDetailRepo.GenerateToken(user.UserName);

                return Ok(new { username = user.UserName, token = token });
                
            }
            catch (ApplicationException ex)
            {
                return BadRequest(new { message = ex.Message });
            }

        }

        [HttpPost("validate/token")]
        public IActionResult IsTokenValid([FromBody] string token)
        {
            var obj = _userDetailRepo.isTokenValid(token);
            return Ok(obj);
        }
    }
}
