﻿using Microsoft.EntityFrameworkCore;
using MyAuthService.Models;

namespace MyAuthService.Data
{
    public class ApplicationDbContext: DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options): base(options) { }

        public DbSet<UserDetail> UserDetails { get; set; } = null!;
    }
}
